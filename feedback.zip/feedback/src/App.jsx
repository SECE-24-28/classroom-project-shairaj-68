import { useState, useEffect } from 'react'
import './App.css'
import api from './api/post'
import Home from './Home'
import Search from './Search'
import AddPost from './AddPost'
import { format } from 'date-fns'


function App() {
  const [Posts, setPosts] = useState([])
  const [search,setsearch]= useState("")
  const [searchresult,setsearchresult]= useState([])
  const [title,setTitle]= useState("")
  const [body,setBody]=useState("")

  
  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await api.get("/feedback")
        console.log('Fetched data:', res.data)
        setPosts(res.data)
      } catch (err) {
        console.error('Error fetching data:', err)
      }
    }
    fetchData()
  }, [])

  //search
  useEffect(()=>
  {
    const filteredPosts=Posts.filter((post)=>post.title.toLowerCase().includes(search.toLowerCase()))
    setsearchresult(filteredPosts)
    
  },[Posts,search])
  const handleSubmit = async (e) => {
    e.preventDefault()
    const id = (Posts.length) ? (Number(Posts[Posts.length-1].id) + 1) : 1
    const datetime = format(new Date(), "MMM dd,yyyy hh:mm:ss")
    const newobj = { id: id, title: title, datetime: datetime, body: body }
    
    try {
      await api.post("/feedback", newobj)
      const newlist = [...Posts, newobj]
      setPosts(newlist)
      setTitle('')
      setBody('')
    } catch (err) {
      console.error('Error saving post:', err)
    }
  }


  return (
    <>
      <h1>Feedback App</h1>
      < Search search={search}  
                     setsearch={setsearch}/>
      <hr />
      <AddPost title={title} setTitle={setTitle} body={body}  setBody={setBody} handleSubmit={handleSubmit}
      />
      <Home Posts={searchresult} />
    </>
  )
}

export default App