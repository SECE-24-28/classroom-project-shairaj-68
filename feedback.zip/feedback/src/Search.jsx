import React from 'react'
import { useContext } from 'react'
import DataContext from './DataContext'

const Search = ({search,setsearch}) => {
    const Search = ({search,setsearch})=>
    {
        const {num}=useContext(DataContext)
    }
  return (
    <div>
        <h1>{num}</h1>
         <input type="text" placeholder='Search' value={search} onChange={(e)=>setsearch(e.target.value)}/>
      
    </div>
  )
}

export default Search
