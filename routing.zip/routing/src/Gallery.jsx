const Gallary = () => {
  return (
    <div>
      <h1>Gallery Page</h1>
      <p>Welcome to the gallery!</p>
    </div>
  )
}

export default Gallary